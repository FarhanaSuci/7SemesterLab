# Queue_OPeration_Animation
Queue operation animation using cpp, in visual studio (own code)
<br>
<h4>intro </h4><br>
<img src="image/1.jpg" ><br>
<h4>structure </h4><br>
<img src="image/2.jpg" ><br>
<h4>insertion</h4><br>
<img src="image/4.jpg" ><br>
<h4>deletion</h4><br>
<img src="image/5.jpg" ><br>


courses = ['Art', 'CompSci','Math','Physics']
courses2 = [1, 3, 4, 2, 5, 6, 7, 8, 9, 10]
#           0, 1, 2, 3, 4, 5, 6, 7, 8, 9
#         -10 -9 -8 -7 -6 -5 -4 -3 -2  -1
# courses.append('Statistics')
# courses.insert(2, 'Statistics')
# courses.remove('Art')
# courses.pop()
# courses.pop(0)
# courses.extend(courses2)
# courses2.sort()
# courses2.reverse()
# courses.sort(reverse=='True')
# courses.sort(reverse=True)

# print(courses2[-1::-1])
print(courses2)
#[start:end:step]
